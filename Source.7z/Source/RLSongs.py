import os
import tkinter as tk
from tkinter import scrolledtext, filedialog
import shutil
import sys
from tkinter import scrolledtext

# Add a scrolled text widget to display logs

window = tk.Tk()
window.title("RLSongs V2")

log = scrolledtext.ScrolledText(window, width=60, height=10)
log.grid(column=0, row=0, columnspan=4, padx=10, pady=10)

#script_dir = sys.path[0]
# Get the path to the directory containing the executable or script
executable_path = sys.argv[0]
executable_directory = os.path.dirname(executable_path)

# Directory to construct absolute paths to your files
source_file_mappings = os.path.join(executable_directory, 'file_mappings.txt')
source_inputdelete = os.path.join(executable_directory, 'inputdelete.txt')

script_dir = os.path.dirname(os.path.abspath(__file__))

def load_file_mappings(directory):
    global file_mappings
    file_mappings_file = os.path.join(directory, 'file_mappings.txt')
    file_mappings = {}
    if os.path.exists(file_mappings_file):
        with open(file_mappings_file, 'r') as fm:
            for mapping_line in fm:
                # Split the line using ':' as the delimiter
                parts = mapping_line.strip().split(':')
                # Check if the line has the expected format
                if len(parts) == 2:
                    file_id, title = parts
                    file_mappings[title.strip()] = file_id.strip()
                else:
                    # Print a warning or handle the unexpected format
                    print("Warning: Line does not have the expected format:", mapping_line)
        log.insert(tk.END, 'File mappings loaded.\n')
    else:
        log.insert(tk.END, 'Error: songs.txt not found.\n')
        map_less()
        if not os.path.exists(file_mappings_file):
            log.insert(tk.END, 'Error: map_less failed.\n')


def find_directory():
    global target_directory
    # Find the directory containing \rocketleague\TAGame\CookedPCConsole
    target_directory = None
    for root, dirs, files in os.walk('/'):
        if 'CookedPCConsole' in dirs:
            target_directory = os.path.join(root, 'CookedPCConsole')
            break

    if target_directory:
        log.insert(tk.END, f"Directory found: {target_directory}\n")
        set_directory(target_directory)
        
        # Check if file_mappings.txt and inputdelete.txt exist in the target directory
        if  not os.path.exists(os.path.join(target_directory, 'inputdelete.txt')):
            dlt_less()
            
            
           
        
        if not os.path.exists(os.path.join(target_directory, 'file_mappings.txt')):
            map_less()

        else:
            load_file_mappings(target_directory)  # Reload file mappings if they already exist
        
        search_files()  # Reload search results
    else:
        log.insert(tk.END, "Directory not found.\n")
        disable_buttons()

def map_less():
    shutil.copy(os.path.join(script_dir, 'file_mappings.txt'), target_directory)
    log.insert(tk.END, 'file_mappings.txt was not found in the directory, a new one has been copied to the directory.\n')
    # Reload the file mappings after copying
    load_file_mappings(target_directory)

def dlt_less():
    shutil.copy(os.path.join(script_dir, 'inputdelete.txt'), target_directory)
    log.insert(tk.END, 'inputdelete.txt was not found in the directory, a new one has been copied to the directory.\n')


def set_directory(directory):
    global target_directory
    target_directory = directory
    log.insert(tk.END, f"Directory set to: {target_directory}\n")
    enable_buttons()
            

def search_files():
    if not in_edit_mode.get():  # Check if not in edit mode
        search_term = search_entry.get().lower()
        results_listbox.delete(0, tk.END)
        
        # Search file mappings
        for title, file_id in file_mappings.items():
            if search_term.lower() in title.lower():  # Case-insensitive search
                results_listbox.insert(tk.END, f"{title} - {file_id}")

def search_input_files():
    if in_edit_mode.get():  # Check if in edit mode
        search_term = input_search_entry.get().lower()
        results_listbox.delete(0, tk.END)
        
        # Search inputdelete.txt
        input_file = os.path.join(target_directory, "inputdelete.txt")
        if os.path.exists(input_file):
            with open(input_file, 'r') as f:
                for line in f:
                    file_ids = line.strip().split()
                    for file_id in file_ids:
                        title = None
                        if file_id in file_mappings.values():
                            title = [title for title, fid in file_mappings.items() if fid == file_id][0]
                        if title and (search_term.lower() in file_id.lower() or search_term.lower() in title.lower()):
                            results_listbox.insert(tk.END, f"{title} - {file_id}")


def reload_search_results():
    results_listbox.delete(0, tk.END)
    search_files()

skip_code = False

def add_selected_files():

    global skip_code
    skip_code = False
    selected_items = results_listbox.curselection()
    input_file = os.path.join(target_directory, "inputdelete.txt")

    # Check if no files are selected
    if not selected_items:
        log.insert(tk.END, "Error: No files selected.\n")
        return


    # Read existing file IDs and preserve their order
    existing_file_ids = []
    if os.path.exists(input_file):
        with open(input_file, 'r') as f:
            existing_file_ids = f.read().strip().split()

    # Add selected file IDs that are not already present
    new_file_ids = []
    for index in selected_items:
        selected_file = results_listbox.get(index)
        file_id = selected_file.split("-")[-1].strip()
        if file_id not in existing_file_ids and file_id not in new_file_ids:
            new_file_ids.append(file_id)
        else:
            # Retrieve the title corresponding to the file ID
            if file_id in file_mappings.values():
                title = [t for t, fid in file_mappings.items() if fid == file_id][0]
            # Message warning the user that the file is already in the list
            log.insert(tk.END, "Error: '{}' (ID: {}) is already in the list.\n".format(title, file_id))
            skip_code = True

    if not skip_code:
    # Append new file IDs after existing file IDs
        all_file_ids = existing_file_ids + new_file_ids

    # Write all file IDs to inputdelete.txt
        with open(input_file, "w") as f:
            f.write(" ".join(all_file_ids) + "\n")

        log.insert(tk.END, "Selected files added to inputdelete.txt.\n")

def select_directory():
    directory = filedialog.askdirectory()
    if directory:
        set_directory(directory)
        load_file_mappings(directory)
        search_files()  # Reload search results

# Boolean for move_files
files_moved = False


def move_files():
    global files_moved 
    files_moved = False
    # Create the DELETE directory if it doesn't exist
    delete_directory = os.path.join(target_directory, 'DELETE')
    if not os.path.exists(delete_directory):
        os.makedirs(delete_directory)

    # Read file IDs to be removed from inputdelete.txt
    input_file = os.path.join(target_directory, 'inputdelete.txt')
    if not os.path.exists(input_file):
        log.insert(tk.END, 'Error: inputdelete.txt not found.\n')
        dlt_less()
        return

    # Process each line in inputdelete.txt
    with open(input_file, 'r') as f:
        for line in f:
            file_ids = line.strip().split()
            log.insert(tk.END, 'Processing file IDs: {}\n'.format(file_ids))

            # Process each file ID in the current line
            for file_to_remove in file_ids:
                if file_to_remove in file_mappings.values():
                    for filename in os.listdir(target_directory):
                        if file_to_remove in filename:
                            # Check if the file already exists in DELETE directory
                            if os.path.exists(os.path.join(delete_directory, filename)):
                                # Delete the existing file in DELETE directory
                                log.insert(tk.END, 'Deleting existing file {} in DELETE directory...\n'.format(filename))
                                os.remove(os.path.join(delete_directory, filename))

                            # Move file to DELETE directory
                            log.insert(tk.END, 'Moving {} to DELETE directory...\n'.format(filename))
                            os.rename(os.path.join(target_directory, filename), os.path.join(delete_directory, filename))
                            if file_to_remove in file_mappings.values():
                                title = [title for title, fid in file_mappings.items() if fid == file_to_remove][0]
                                log.insert(tk.END, 'Title: {}\n'.format(title))
                            files_moved = True
                            break
                else:
                    log.insert(tk.END, 'Error: File ID {} not found in mappings.\n'.format(file_to_remove))
    if files_moved:
        log.insert(tk.END, 'All files processed.\n')
    else:
        log.insert(tk.END, 'No files were moved.\n')

def use_check(target_directory):
    for root, dirs, files in os.walk(target_directory):
        for filename in files:
            if filename.endswith(".wem") or filename.endswith(".ewem"):
                file_path = os.path.join(root, filename)
                try:
                    # Attempt to open the file in exclusive mode for reading
                    with os.fdopen(os.open(file_path, os.O_WRONLY | os.O_EXCL), 'rb') as f:
                        # Debug purposes only
                        print(f"File '{file_path}' is not in use")
                except PermissionError:
                    file_base_name = os.path.splitext(filename)[0]
                    # Open file_mappings.txt and look for the corresponding title
                    file_mappings_path = os.path.join(target_directory, 'file_mappings.txt')
                    if os.path.exists(file_mappings_path):
                        with open(file_mappings_path, 'r') as file_mappings_file:
                            for line in file_mappings_file:
                                parts = line.strip().split(':')
                                if len(parts) == 2:
                                    mapping_filename, title = parts
                                    if file_base_name == mapping_filename.strip():
                                        log.insert(tk.END, "Current song playing is '{}'.\n".format(title.strip()))
                                        break
                            else:
                                log.insert(tk.END, "Current song playing is '{}'. (Title not found in file_mappings.txt, automatic file mapping implentation will be added in a future update.)\n".format(filename))
                    else:
                        log.insert(tk.END, "Error: file_mappings.txt not found in the directory.\n")


    
def debug():
    print()



def edit_list():
    in_edit_mode.set(True)
    edit_button.grid_remove()
    add_button.grid_remove()
    move_button.grid_remove()
    remove_selected_button.grid()
    add_back_button.grid()
    exit_edit_button.grid()
    input_search_entry.grid()
    input_search_button.grid()

    input_file = os.path.join(target_directory, 'inputdelete.txt')
    if os.path.exists(input_file):
        results_listbox.delete(0, tk.END)
        with open(input_file, 'r') as f:
            for line in f:
                file_ids = line.strip().split()
                for file_id in file_ids:
                    title = None
                    if file_id in file_mappings.values():
                        title = [title for title, fid in file_mappings.items() if fid == file_id][0]
                    if title:
                        results_listbox.insert(tk.END, f"{title} - {file_id}")
    else:
        log.insert(tk.END, 'Error: inputdelete.txt not found.\n')

def remove_selected_files():
    selected_items = results_listbox.curselection()
    input_file = os.path.join(target_directory, "inputdelete.txt")

    with open(input_file, "r+") as f:
        lines = f.readlines()
        f.seek(0)
        for index, line in enumerate(lines):
            file_ids = line.strip().split()
            updated_file_ids = [file_id for idx, file_id in enumerate(file_ids) if idx not in selected_items]
            if updated_file_ids:
                f.write(' '.join(updated_file_ids) + '\n')
        f.truncate()

    results_listbox.delete(0, tk.END)
    edit_list()



def add_songs_back():
    input_file = os.path.join(target_directory, "inputdelete.txt")
    delete_directory = os.path.join(target_directory, 'DELETE')
    if not os.path.exists(delete_directory):
        log.insert(tk.END, 'Error: DELETE directory not found.\n')
        return

    # Read file IDs from inputdelete.txt
    existing_file_ids = set()
    if os.path.exists(input_file):
        with open(input_file, 'r') as f:
            existing_file_ids.update(f.read().strip().split())

    # Move files from DELETE folder back to CookedPCConsole directory
    moved_files = 0
    for filename in os.listdir(delete_directory):
        file_id = filename.split('.')[0]  # Extract file ID from filename
        if file_id not in existing_file_ids:
            source_file = os.path.join(delete_directory, filename)
            destination_file = os.path.join(target_directory, filename)
            shutil.move(source_file, destination_file)
            moved_files += 1
            
# Log the title and ID of the moved file
            title = [title for title, fid in file_mappings.items() if fid == file_id][0]
            log.insert(tk.END, 'Moved file back: {} - {}\n'.format(title, file_id))

    # Toggle edit mode after adding back songs
    exit_edit_mode()


def exit_edit_mode():
    in_edit_mode.set(False)
    edit_button.grid()
    add_button.grid()
    move_button.grid()
    remove_selected_button.grid_remove()
    add_back_button.grid_remove()
    exit_edit_button.grid_remove()
    disable_input_search()
    enable_search()
    reload_search_results()

def disable_buttons():
    add_button.config(state=tk.DISABLED)
    move_button.config(state=tk.DISABLED)
    edit_button.config(state=tk.DISABLED)
    search_button.config(state=tk.DISABLED)
    select_button.config(state=tk.DISABLED)
    disable_input_search()

def enable_buttons():
    add_button.config(state=tk.NORMAL)
    move_button.config(state=tk.NORMAL)
    edit_button.config(state=tk.NORMAL)
    search_button.config(state=tk.NORMAL)
    select_button.config(state=tk.NORMAL)
    enable_search()

def enable_search():
    search_label.grid()
    search_entry.grid()
    search_button.grid()

def disable_search():
    search_label.grid_remove()
    search_entry.grid_remove()
    search_button.grid_remove()

def enable_input_search():
    input_search_entry.grid()
    input_search_button.grid()

def disable_input_search():
    input_search_entry.grid_remove()
    input_search_button.grid_remove()


# Create tkinter window

#exe_directory = getattr(sys, '_MEIPASS', os.path.abspath(os.path.dirname(__file__)))

#icon_path = os.path.join(exe_directory, 'RLSongs.ico')

#window.iconbitmap(os.path.join(script_dir,'RLSongs.ico'))

# Add a button to search for directory
find_button = tk.Button(window, text="Automatic Find Directory", command=find_directory)
find_button.grid(column=0, row=1, padx=10, pady=5)

# Add a button to manually select directory
select_button = tk.Button(window, text="Manual Select Directory", command=select_directory)
select_button.grid(column=1, row=1, padx=10, pady=5)

# Add a search entry
search_label = tk.Label(window, text="Search:")
search_label.grid(column=0, row=2, padx=10, pady=5)
search_entry = tk.Entry(window, width=40)
search_entry.grid(column=1, row=2, padx=10, pady=5)

# Add a search button
search_button = tk.Button(window, text="Search", command=search_files)
search_button.grid(column=2, row=2, padx=10, pady=5)

# Add a search entry for inputdelete.txt
input_search_entry = tk.Entry(window, width=40)
input_search_entry.grid(column=1, row=2, padx=10, pady=5)
input_search_entry.grid_remove()

# Add a search button for inputdelete.txt
input_search_button = tk.Button(window, text="Search", command=search_input_files)
input_search_button.grid(column=2, row=2, padx=10, pady=5)
input_search_button.grid_remove()

# Add a listbox to display search results
results_listbox = tk.Listbox(window, selectmode=tk.MULTIPLE, width=60, height=20)
results_listbox.grid(column=0, row=3, columnspan=4, padx=10, pady=5)

# Add a button to add selected files to inputdelete.txt
add_button = tk.Button(window, text="Add Selected Files To The List", command=add_selected_files)
add_button.grid(column=0, row=4, columnspan=4, padx=10, pady=5)

# Add a button to move files to DELETE directory
move_button = tk.Button(window, text="Remove All Songs In The List", command=move_files)
move_button.grid(column=0, row=5, columnspan=4, padx=10, pady=5)

# Add a button to edit list
edit_button = tk.Button(window, text="Edit Mode", command=edit_list)
edit_button.grid(column=0, row=6, columnspan=4, padx=10, pady=5)

# Add button for removing selected files
remove_selected_button = tk.Button(window, text="Remove Selected Files From The List", command=remove_selected_files)
remove_selected_button.grid(column=0, row=7, columnspan=4, padx=10, pady=5)
remove_selected_button.grid_remove()

# Add button for adding songs back
add_back_button = tk.Button(window, text="Add Songs Back", command=add_songs_back)
add_back_button.grid(column=0, row=8, columnspan=4, padx=10, pady=5)
add_back_button.grid_remove()

# Add button for exiting edit mode
exit_edit_button = tk.Button(window, text="Exit Edit Mode", command=exit_edit_mode)
exit_edit_button.grid(column=0, row=9, columnspan=4, padx=10, pady=5)
exit_edit_button.grid_remove()

# Add a button to run the use_check function
select_button = tk.Button(window, text="Current Song Playing", command=lambda: use_check(target_directory))
select_button.grid(column=0, row=4, padx=10, pady=5)

# Add a button to run the use_check function
#select_button = tk.Button(window, text="Debug", command= debug)
#select_button.grid(column=0, row=4, padx=10, pady=5)


# Variable to track if in edit mode
in_edit_mode = tk.BooleanVar()
in_edit_mode.set(False)

disable_buttons()

window.mainloop()

